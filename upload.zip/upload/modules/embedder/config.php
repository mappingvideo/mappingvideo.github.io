<?php
$sites = array(
	'youtube.com' => 'youtube'
);
?>